# LCD1602A-Functions-STM32F103C8T6
LCD 1602A FUNCTIONS.h and basic LCD string Display

This code contains interfacing of STM32F103C8T6 with LCD 1602A. 
A Self made LCD Header file for user functions. Easy to understand for beginners.
